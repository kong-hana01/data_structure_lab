#pragma once
#include "Student.h"

template <class  ItemType >
void ReheapDown(ItemType stu[], int iparent, int ibottom) {
	int minChild, rightChild, leftChild;
	leftChild = iparent * 2 + 1;
	rightChild = iparent * 2 + 2;
	if (leftChild <= ibottom) {
		if (leftChild == ibottom) {
			minChild = leftChild;
		}
		else {
			minChild = stu[leftChild] > stu[rightChild] ? rightChild : leftChild;
		}
		if (stu[iparent] > stu[minChild]) {
			ItemType item = stu[iparent];
			stu[iparent] = stu[minChild];
			stu[minChild] = item;
			ReheapDown(stu, minChild, ibottom);
		}
	}
}

template <class  ItemType >
void ReheapUp(ItemType stu[], int iroot, int ibottom) {
	int parent;

	if (ibottom > iroot) {
		parent = (ibottom - 1) / 2;
		if (stu[parent] > stu[ibottom]) {
			ItemType item = stu[parent];
			stu[parent] = stu[ibottom];
			stu[ibottom] = item;
			ReheapDown(stu, iroot, parent);
		}
	}
}

template <class  ItemType >
void print(ItemType values[], int numValues) {
	for (int index = 0; index < numValues; index++) {
		std::cout << values[index] << " ";
	}
	std::cout << endl;
}

template <class  ItemType >
void Swap(ItemType& item1, ItemType& item2)
// Post: Contents of item1 and item2 have been swapped.
{
	ItemType tempItem;

	tempItem = item1;
	item1 = item2;
	item2 = tempItem;
}

template <class  ItemType >
void  HeapSort(ItemType  values[], int  numValues)
{
	int  index;
	print(values, numValues);
	for (index = numValues / 2 - 1; index >= 0; index--) {
		ReheapDown(values, index, numValues - 1);
		print(values, numValues);
	}

	std::cout << "Heap �迭" << endl;
	print(values, numValues);

	for (index = numValues - 1; index >= 1; index--)
	{
		Swap(values[0], values[index]);
		ReheapDown(values, 0, index - 1);
		print(values, numValues);
	}
}


template <class  ItemType >
int  GetHeight(ItemType values[], int start, int numValues)
{
	if ((start * 2 + 1) >= numValues) return 0; // start�� leaf�̰ų� tree �ۿ� �ִ� ���
	int l_height = GetHeight(values, start * 2 + 1, numValues); // left subtree�� height
	int r_height = GetHeight(values, start * 2 + 2, numValues); // right subtree�� height
	return max(l_height, r_height) + 1; // ��subtree height �� ū �� + 1�� �� ����
}



template <class  ItemType >
int  GetHeightSum(ItemType values[], int numValues)
{
	int  index, sum = 0, temp;
	// non-leaf ��忡 ���� �� ��带 ��Ʈ�� �ϴ� subtree�� height ���
	for (index = 0; index < numValues; index++) {
		temp = GetHeight(values, index, numValues - 1);
		sum += temp;
		std::cout << index << "��° ��带 root�� �ϴ� height ��:" << temp << endl;
	}

	cout << "sum of heights = " << sum << endl;
	return sum;
}
