#include <iostream>
#include "Student.h"
#include "SelectionSort.h"
#include "BubbleSort.h"
#include "InsertionSort.h"
#include "HeapSort.h"
using namespace std;


void createStudents(Student stu[]) {
	stu[0].InitValue(2003200111, "�̿���", 3.0);
	stu[1].InitValue(2004200121, "�ǿ���", 3.2);
	stu[2].InitValue(2005200132, "������", 2.7);
}

template <class  ItemType >
int  GetHeight(ItemType values[], int start, int numValues);

int main() {
	Student stu[100];

	// SelectionSort
	createStudents(stu);
	cout << "Selection sort ���� ����" << endl;
	Print(cout, stu, 3);
	SelectionSort(stu, 3);
	cout << "Selection sort ���� ����" << endl;
	Print(cout, stu, 3);
	cout << endl;

	// BubbleSort
	createStudents(stu);
	cout << "Bubble sort ���� ����" << endl;
	Print(cout, stu, 3);
	BubbleSort(stu, 3);
	cout << "Bubble sort ���� ����" << endl;
	Print(cout, stu, 3);
	cout << endl;


	// InsertionSort
	createStudents(stu);
	cout << "Insertion sort ���� ����" << endl;
	Print(cout, stu, 3);
	InsertionSort(stu, 3);
	cout << "Insertion sort ���� ����" << endl;
	Print(cout, stu, 3);
	cout << endl;

	createStudents(stu);
	int arr[] = {25, 17, 36, 2, 3, 100, 1, 19, 7};
	HeapSort(arr, 9);

	GetHeightSum(arr, 9);
	return 0;
}
